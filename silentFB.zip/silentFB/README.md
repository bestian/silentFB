# silentFB
silentFB -- a Simple Chrome Extension

make Facebook UI slient to prevent overstimulation.

## Install

1. download .zip
2. use chrome > settings > extensions > load unpacked extension
